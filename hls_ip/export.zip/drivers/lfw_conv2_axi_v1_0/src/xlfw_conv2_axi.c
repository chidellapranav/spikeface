// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xlfw_conv2_axi.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLfw_conv2_axi_CfgInitialize(XLfw_conv2_axi *InstancePtr, XLfw_conv2_axi_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLfw_conv2_axi_Start(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL) & 0x80;
    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLfw_conv2_axi_IsDone(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLfw_conv2_axi_IsIdle(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLfw_conv2_axi_IsReady(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLfw_conv2_axi_EnableAutoRestart(XLfw_conv2_axi *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL, 0x80);
}

void XLfw_conv2_axi_DisableAutoRestart(XLfw_conv2_axi *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL, 0);
}

void XLfw_conv2_axi_Set_params(XLfw_conv2_axi *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_PARAMS_DATA, (u32)(Data));
    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_PARAMS_DATA + 4, (u32)(Data >> 32));
}

u64 XLfw_conv2_axi_Get_params(XLfw_conv2_axi *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_PARAMS_DATA);
    Data += (u64)XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_PARAMS_DATA + 4) << 32;
    return Data;
}

void XLfw_conv2_axi_Set_beta(XLfw_conv2_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_BETA_DATA, Data);
}

u32 XLfw_conv2_axi_Get_beta(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_BETA_DATA);
    return Data;
}

void XLfw_conv2_axi_Set_threshold(XLfw_conv2_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_THRESHOLD_DATA, Data);
}

u32 XLfw_conv2_axi_Get_threshold(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_THRESHOLD_DATA);
    return Data;
}

void XLfw_conv2_axi_Set_clear_state(XLfw_conv2_axi *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_CLEAR_STATE_DATA, Data);
}

u32 XLfw_conv2_axi_Get_clear_state(XLfw_conv2_axi *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_CLEAR_STATE_DATA);
    return Data;
}

void XLfw_conv2_axi_InterruptGlobalEnable(XLfw_conv2_axi *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_GIE, 1);
}

void XLfw_conv2_axi_InterruptGlobalDisable(XLfw_conv2_axi *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_GIE, 0);
}

void XLfw_conv2_axi_InterruptEnable(XLfw_conv2_axi *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_IER);
    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_IER, Register | Mask);
}

void XLfw_conv2_axi_InterruptDisable(XLfw_conv2_axi *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_IER);
    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_IER, Register & (~Mask));
}

void XLfw_conv2_axi_InterruptClear(XLfw_conv2_axi *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLfw_conv2_axi_WriteReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_ISR, Mask);
}

u32 XLfw_conv2_axi_InterruptGetEnabled(XLfw_conv2_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_IER);
}

u32 XLfw_conv2_axi_InterruptGetStatus(XLfw_conv2_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLfw_conv2_axi_ReadReg(InstancePtr->Ctrl_BaseAddress, XLFW_CONV2_AXI_CTRL_ADDR_ISR);
}

