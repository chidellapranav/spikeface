// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// CTRL
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of params
//        bit 31~0 - params[31:0] (Read/Write)
// 0x14 : Data signal of params
//        bit 31~0 - params[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of beta
//        bit 31~0 - beta[31:0] (Read/Write)
// 0x20 : reserved
// 0x24 : Data signal of threshold
//        bit 31~0 - threshold[31:0] (Read/Write)
// 0x28 : reserved
// 0x2c : Data signal of clear_state
//        bit 0  - clear_state[0] (Read/Write)
//        others - reserved
// 0x30 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XLFW_CONV2_AXI_CTRL_ADDR_AP_CTRL          0x00
#define XLFW_CONV2_AXI_CTRL_ADDR_GIE              0x04
#define XLFW_CONV2_AXI_CTRL_ADDR_IER              0x08
#define XLFW_CONV2_AXI_CTRL_ADDR_ISR              0x0c
#define XLFW_CONV2_AXI_CTRL_ADDR_PARAMS_DATA      0x10
#define XLFW_CONV2_AXI_CTRL_BITS_PARAMS_DATA      64
#define XLFW_CONV2_AXI_CTRL_ADDR_BETA_DATA        0x1c
#define XLFW_CONV2_AXI_CTRL_BITS_BETA_DATA        32
#define XLFW_CONV2_AXI_CTRL_ADDR_THRESHOLD_DATA   0x24
#define XLFW_CONV2_AXI_CTRL_BITS_THRESHOLD_DATA   32
#define XLFW_CONV2_AXI_CTRL_ADDR_CLEAR_STATE_DATA 0x2c
#define XLFW_CONV2_AXI_CTRL_BITS_CLEAR_STATE_DATA 1

