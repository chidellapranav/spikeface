// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XLFW_READOUT_AXI_H
#define XLFW_READOUT_AXI_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlfw_readout_axi_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Ctrl_BaseAddress;
} XLfw_readout_axi_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XLfw_readout_axi;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLfw_readout_axi_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLfw_readout_axi_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLfw_readout_axi_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLfw_readout_axi_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XLfw_readout_axi_Initialize(XLfw_readout_axi *InstancePtr, u16 DeviceId);
XLfw_readout_axi_Config* XLfw_readout_axi_LookupConfig(u16 DeviceId);
int XLfw_readout_axi_CfgInitialize(XLfw_readout_axi *InstancePtr, XLfw_readout_axi_Config *ConfigPtr);
#else
int XLfw_readout_axi_Initialize(XLfw_readout_axi *InstancePtr, const char* InstanceName);
int XLfw_readout_axi_Release(XLfw_readout_axi *InstancePtr);
#endif

void XLfw_readout_axi_Start(XLfw_readout_axi *InstancePtr);
u32 XLfw_readout_axi_IsDone(XLfw_readout_axi *InstancePtr);
u32 XLfw_readout_axi_IsIdle(XLfw_readout_axi *InstancePtr);
u32 XLfw_readout_axi_IsReady(XLfw_readout_axi *InstancePtr);
void XLfw_readout_axi_EnableAutoRestart(XLfw_readout_axi *InstancePtr);
void XLfw_readout_axi_DisableAutoRestart(XLfw_readout_axi *InstancePtr);

void XLfw_readout_axi_Set_params(XLfw_readout_axi *InstancePtr, u64 Data);
u64 XLfw_readout_axi_Get_params(XLfw_readout_axi *InstancePtr);
void XLfw_readout_axi_Set_beta(XLfw_readout_axi *InstancePtr, u32 Data);
u32 XLfw_readout_axi_Get_beta(XLfw_readout_axi *InstancePtr);
void XLfw_readout_axi_Set_clear_state(XLfw_readout_axi *InstancePtr, u32 Data);
u32 XLfw_readout_axi_Get_clear_state(XLfw_readout_axi *InstancePtr);

void XLfw_readout_axi_InterruptGlobalEnable(XLfw_readout_axi *InstancePtr);
void XLfw_readout_axi_InterruptGlobalDisable(XLfw_readout_axi *InstancePtr);
void XLfw_readout_axi_InterruptEnable(XLfw_readout_axi *InstancePtr, u32 Mask);
void XLfw_readout_axi_InterruptDisable(XLfw_readout_axi *InstancePtr, u32 Mask);
void XLfw_readout_axi_InterruptClear(XLfw_readout_axi *InstancePtr, u32 Mask);
u32 XLfw_readout_axi_InterruptGetEnabled(XLfw_readout_axi *InstancePtr);
u32 XLfw_readout_axi_InterruptGetStatus(XLfw_readout_axi *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
