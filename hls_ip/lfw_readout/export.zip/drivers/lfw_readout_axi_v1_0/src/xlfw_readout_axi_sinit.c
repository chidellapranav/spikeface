// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xlfw_readout_axi.h"

extern XLfw_readout_axi_Config XLfw_readout_axi_ConfigTable[];

XLfw_readout_axi_Config *XLfw_readout_axi_LookupConfig(u16 DeviceId) {
	XLfw_readout_axi_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XLFW_READOUT_AXI_NUM_INSTANCES; Index++) {
		if (XLfw_readout_axi_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XLfw_readout_axi_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLfw_readout_axi_Initialize(XLfw_readout_axi *InstancePtr, u16 DeviceId) {
	XLfw_readout_axi_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLfw_readout_axi_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLfw_readout_axi_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

